// JavaScript source code
var fahrenheit;
var celsius;

function begin() {
    debugger;
 try{
     var temp = $('#inputVal').val();

     if (temp === "" || " ") {
         throw new Error('No input');
         alert("No Input");
         alert('Cannot be blank');
         }
     if (isNaN(temp)) {
         throw new Error('Not a number');
         alert('Please enter a numeric character');}

    //temp is valid input at this stage 
    if (document.getElementById('cel').checked) {
        celConvert(temp);
    }

    if (document.getElementById('fah').checked) {
        fahConvert(temp);
    }
   }
    catch (excep) {
        console.log('General Error' + excep.message);
    }
}

function celConvert(temp) {
    try{
        var temp = $('#inputVal').val();
        $('#fahrenheit').text(temp * 1.8 + 32);
    }
    catch (ex) {
        throw ex;
    }
}


function fahConvert(temp) {
    try {
        var temp = $('#inputVal').val();
        $('#celsius').text(temp - 32) / 1.8;
    }
    catch (ex) {
        throw ex;
        $('#message').text('Error');
    }
}
function clearAll() {
    $('#cel').prop('checked', false);
    $('#fah').prop('checked', false);
    $('#inputVal').val('');
}
function exit() {
    $('#content').fadeOut(2000);
    $('h3').text('Goodbye!!');
}


